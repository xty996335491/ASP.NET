﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Home.aspx.cs" Inherits="MusicMania.Home" MasterPageFile="~/ParentMasterPage.Master" %>
 <asp:Content ID="Content1" ContentPlaceholderID="ContentPlaceHolder1" runat="server">
     <div>
                        <u><b>
                            <br />
                            Welcome to the MusicMania store!</b></u>
                        <br />
                        <br />
                        MusicMania is a unique platform for music lovers. It has a great variety of music albums. 
                        <br />
                        <br />

                        <u><b>Join the music club</b></u>
                        <ul>
                            <li>Get the membership of six months&#39; worth $500.</li>
                            <li>Get 10% discount.</li>
                            <li>Get music CDs free worth $50.</li>
                        </ul>
                        
                        <asp:HyperLink ID="HyperLink4" runat="server" NavigateUrl="Registration.aspx" ToolTip="Click here to register" ForeColor="Blue">Click here to join the music club</asp:HyperLink>

          </div>
                  </asp:Content>
