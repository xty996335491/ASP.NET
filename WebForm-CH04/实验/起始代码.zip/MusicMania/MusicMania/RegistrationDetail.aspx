﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="RegistrationDetail.aspx.cs" Inherits="MusicMania.RegistrationDetail" MasterPageFile="~/ParentMasterPage.Master" %>
 <asp:Content ID="Content1" ContentPlaceholderID="ContentPlaceHolder1" runat="server">
        <table style="width:100%">
            <tr>
             <td>
                 <asp:Panel ID="Panel1" runat="server">
                 </asp:Panel>
                </td>   
                
            </tr>          
            
        </table>
         </asp:Content>
