﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="AboutUs.aspx.cs" Inherits="MusicMania.AboutUs" MasterPageFile="~/ParentMasterPage.Master" %>
 <asp:Content ID="Content1" ContentPlaceholderID="ContentPlaceHolder1" runat="server">
<div>

                        <u><b>
                        <br />
                        Welcome to the MusicMania store!</b></u><br />
                        <br />
                        MusicMania, established on 2nd March, 2000, has 100 stores across the US. 
                        <br />
                        It is a unique platform of music that caters to the tastes of all kinds of music lovers.<br />
                        MusicMania is famous for its huge music collection and excellent customer services.<br />
                        <br />
                        <u><b>Vision</b></u><br />
                        <br />
                        MusicMania aims to become the country&#39;s most preferred retailer for music, be present at the consumer&#39;s choice of access, and deliver the products on time.
                    <br />
                        <br />
                        <u><b>Mission</b></u><br />
                        <ul>
                            <li>To provide best customer services to ensure complete customer satisfaction</li>
                            <li>To become the largest provider for music in the US</li>
                           
                        </ul>    
</div>
</asp:Content>
