﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MusicMania
{
    public partial class RegistrationDetail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (PreviousPage != null)
            {
                ContentPlaceHolder cp = PreviousPage.Master.FindControl("ContentPlaceHolder1") as ContentPlaceHolder;
                if (cp != null)
                {
                    TextBox tb1 = cp.FindControl("fname") as TextBox;
                    TextBox tb2 = cp.FindControl("lname") as TextBox;
                    TextBox tb3 = cp.FindControl("dobval") as TextBox;
                    TextBox tb4 = cp.FindControl("emailId") as TextBox;
                    TextBox tb5 = cp.FindControl("address") as TextBox;
                    ListBox preference1 = (ListBox)cp.FindControl("preference");
                    List<ListItem> items = new List<ListItem>();
                    foreach (ListItem listitem in preference1.Items)
                    {
                        if (listitem.Selected)
                            items.Add(listitem);

                    }

                    Label TestLabel1 = new Label();
                    if (tb1 != null && tb2 != null)
                        TestLabel1.Text = "Welcome to MusicMania " + tb1.Text + " " + tb2.Text + "!<br/><br/>" + "You have submitted the following registration details:<br/>" + "</br>Date of birth: " + tb3.Text + "<br/>" + "EmailID: " + tb4.Text + "<br/>Address: " + tb5.Text + "<br/><ul>Preferences: ";

                    foreach (ListItem i in items)
                        TestLabel1.Text += "<li>" + (i.Value);

                    Panel1.Controls.Add(TestLabel1);
                }
            }


        }
    }
}