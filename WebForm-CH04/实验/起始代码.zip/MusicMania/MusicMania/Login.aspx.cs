﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MusicMania
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text == "john" && TextBox2.Text == "john@123")
            {
              
             Response.Redirect("Welcome.aspx?Name=" + TextBox1.Text);
            }
          
               
            }
        }
    
}
