﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Welcome.aspx.cs" Inherits="MusicMania.Welcome" MasterPageFile="~/ParentMasterPage.Master" %>

<asp:Content ID="Content1" ContentPlaceholderID="ContentPlaceHolder1" runat="server">
     <br /><asp:Label ID="Label1" runat="server"></asp:Label>
     
    
     </asp:Content>
