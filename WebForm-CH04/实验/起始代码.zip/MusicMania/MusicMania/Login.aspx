﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Login.aspx.cs" Inherits="MusicMania.Login" MasterPageFile="~/ParentMasterPage.Master" %>

<asp:Content ID="Content1" ContentPlaceholderID="ContentPlaceHolder1" runat="server">
     <br />
     Username:&nbsp;&nbsp;
     <asp:TextBox ID="TextBox1" runat="server"></asp:TextBox>
     <br />
     Password: &nbsp;
     <asp:TextBox ID="TextBox2" runat="server" TextMode="Password"></asp:TextBox><br /><br />
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     <asp:Button ID="Button1" runat="server" OnClick="Button1_Click" Text="Login" />
     <br />
     <br />
         
     </asp:Content>